/*
 * ====================================================================
 * Copyright (c) 2004-2006 TMate Software Ltd.  All rights reserved.
 *
 * This software is licensed as described in the file COPYING, which
 * you should have received as part of this distribution.  The terms
 * are also available at http://tmate.org/svn/license.html.
 * If newer versions of this license are posted there, you may use a
 * newer version instead, at your option.
 * ====================================================================
 */
package org.tmatesoft.svn.core.client;

import java.io.File;

import org.tmatesoft.svn.core.SVNErrorMessage;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNURL;
import org.tmatesoft.svn.core.auth.ISVNAuthenticationManager;
import org.tmatesoft.svn.core.auth.ISVNAuthenticationProvider;
import org.tmatesoft.svn.core.auth.ISVNProxyManager;
import org.tmatesoft.svn.core.auth.SVNAuthentication;
import org.tmatesoft.svn.core.auth.SVNProxyAuthentication;
import org.tmatesoft.svn.core.auth.SVNSSHAuthentication;
import org.tmatesoft.svn.core.auth.SVNSSLAuthentication;
import org.tmatesoft.svn.core.internal.wc.DefaultSVNAuthenticationManager;


/**
 * @version 1.0
 * @author  TMate Software Ltd.
 */
public class SVNClientAuthenticationManager extends DefaultSVNAuthenticationManager {

    private SimpleProxyManager myDefaultProxyManager;
    private SVNSSHAuthentication myDefaultSSHCredentials;
    private SVNSSLAuthentication myDefaultSSLCredentials;
    private SVNSSHAuthentication myDefaultSSHCredentials2;
    private SVNProxyAuthentication myDefaultProxyCredentials;
    private boolean storeAuth;

    public SVNClientAuthenticationManager(File configDirectory, boolean storeAuth, boolean storeSSLAuth, String userName, String password) {
        super(configDirectory, storeAuth, storeSSLAuth, userName, password);
        this.storeAuth = storeAuth;
    }
    
    public void setClientSSLCertificate(String certPath, String passphrase) {
        if (certPath != null) {
            myDefaultSSLCredentials = new SVNSSLAuthentication(new File(certPath), passphrase, this.storeAuth);
        } else {
            myDefaultSSLCredentials = null;
        }
    }
    
    public void setSSHCredentials(String userName, String privateKeyPath, String passphrase, int portNumber) {    	
        if (userName != null && privateKeyPath != null) {
            myDefaultSSHCredentials = new SVNSSHAuthentication(userName, new File(privateKeyPath), passphrase, portNumber, this.storeAuth);
        } else {
            myDefaultSSHCredentials = null;
        }
    }

    public void setSSHCredentials(String userName, String password, int portNumber) {
        if (userName != null) {
            myDefaultSSHCredentials2 = new SVNSSHAuthentication(userName, password, portNumber, this.storeAuth);
        } else {
            myDefaultSSHCredentials2 = null;
        }
    }
    
    public boolean hasProxy() {
        return myDefaultProxyCredentials != null;
    }

    public void setProxy(String host, int port, String userName, String password) {
        if (host != null) {
            myDefaultProxyManager = new SimpleProxyManager(host, port < 0 ? null : Integer.toString(port), userName, password);
            myDefaultProxyCredentials = new SVNProxyAuthentication(userName, password, host, port, this.storeAuth);
        } else {
            myDefaultProxyManager = null;
            myDefaultProxyCredentials = null;
        }
    }

    public ISVNProxyManager getProxyManager(SVNURL url) throws SVNException {
        if (myDefaultProxyManager != null) {
            return myDefaultProxyManager;
        }
        return super.getProxyManager(url);
    }

    protected ISVNAuthenticationProvider createDefaultAuthenticationProvider(String userName, String password, File privateKey, String passphrase, boolean allowSave) {
        return new DefaultProvider(userName, password, privateKey, passphrase, allowSave); 
    }
    
    protected class DefaultProvider extends DumbAuthenticationProvider {
        
        public DefaultProvider(String userName, String password, File privateKey, String passphrase, boolean store) {
            super(userName, password, privateKey, passphrase, store);
        }
        
        public SVNAuthentication requestClientAuthentication(String kind, SVNURL url, String realm, SVNErrorMessage errorMessage, SVNAuthentication previousAuth, boolean authMayBeStored) {
            if (previousAuth == null) {
                if (ISVNAuthenticationManager.SSH.equals(kind) && (myDefaultSSHCredentials != null || myDefaultSSHCredentials2 != null)) {
                    return myDefaultSSHCredentials != null ? myDefaultSSHCredentials : myDefaultSSHCredentials2;
                } else if (ISVNAuthenticationManager.SSL.equals(kind) && myDefaultSSLCredentials != null) {
                    return myDefaultSSLCredentials;
                } else if (ISVNAuthenticationManager.PROXY.equals(kind) && myDefaultProxyCredentials != null) {
                    return myDefaultProxyCredentials;
                }
            } 
            if (ISVNAuthenticationManager.PROXY.equals(kind) && !hasProxy()) {
                return null;
            }
            return super.requestClientAuthentication(kind, url, realm, errorMessage, previousAuth, authMayBeStored);
        }
    }

}
