#define ELEM_TYPE int
#include <iostream>

using namespace std;

struct QueueNode;
struct QueueHeader;
typedef QueueHeader* Queue;



Queue emptyQ()               // O(1)
{
    queueNode* newQueue = new queueNode;

    qh -> first = NULL;
    qh -> last  = NULL;
    qh -> it    = 0;

    return newQueue;
}

bool isEmptyQ(Queue q)        // O(1)
{
    return q->it == 0;
}
void enqueue(ELEM_TYPE x, Queue& q) // O(1)
{
    queueNode* newNode = new queueNode;
    newNode->value = x;
    newNode->next  = NULL;

    if (q->first == NULL)
    {
        q->first = newNode;

    } else {
        q->last->next  = newNode;
    }
    q->last = newNode;
    q->it++;
}


ELEM_TYPE  firstQ(Queue q);          // O(1)
{
    return q->first;
}

void dequeue(Queue& q);        // O(1)
{
    if not (q->first == NULL)
    {
        temp = q -> first;
        q -> first = q -> first -> next;
        delete temp;
    }
    if(q->it == 1) {
        q->last = NULL;
    }
    q -> it--;
}

int sizeQ(Queue q);            // O(1)
{
    return q->it;
}

void printQ(Queue q) //O(n)
{
    QueueNode* actual = q->first;
    cout << "Queue [ ";
    while(actual != NULL)
    {
        if(actual->next != NULL)
        {
             cout << actual->elem << ", ";
        }
        else
        {
           cout << actual->elem << " ";
        }
        actual = actual->next;
    }
    cout << "]" << endl;
}
Queue copyQ(Queue q)        // O(n)
{
    Queue result = emptyQ();
    QIterator qI = initQIt(q);
    while (not finishedQIt(qI))
    {
        enqueue(getCurrentQIt(qI), result);
        nextQIt(qI);
    }
    return result;
}
void destroyQ(Queue& q)       // O(n)
{
    while (q->it > 0)
    {
        dequeue(q);
    }

    delete q;
    q = NULL; //borro el puntero del usuario a la Queue.
}




QIterator initQIt(Queue q); // O(1)
bool finishedQIt(QIterator it); // O(1)
ELEM_TYPE getCurrentQIt(QIterator it); // O(1)
void setCurrentQIt(ELEM_TYPE x, QIterator it); // O(1)
void nextQIt(QIterator& it); // O(1)
