#include "gentree.h"
#include "array_list.h"

struct GNode
{
  T_ELEM_TYPE elem;
  ArrayList children;
};

GenTree leaf(T_ELEM_TYPE x)
{
  /// COMPLETAR
}

bool isLeaf(GenTree t)
{
  /// COMPLETAR
}

T_ELEM_TYPE value(GenTree t)
{
  /// COMPLETAR
}

ArrayList children(GenTree t)
{
  /// COMPLETAR
}

void addChild(GenTree& t, GenTree child)
{
  /// COMPLETAR
}

void destroyTree(GenTree t)
{
  /// COMPLETAR
}
