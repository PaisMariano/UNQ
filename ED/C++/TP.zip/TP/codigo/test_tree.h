#include "gentree.h"
#include "array_list.h"
#include "linked_list.h"
#include <iostream>

using namespace std;

void testTree();
