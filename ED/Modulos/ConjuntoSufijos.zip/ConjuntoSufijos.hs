module ConjuntoSufijos where

data ConjuntoSufijos = CP (Map String (Set String))

vacio :: ConjuntoSufijos
vacio = CP (emptyM)
--Crea una ConjuntoSufijos vacío. O(1).



terminanCon :: String -> ConjuntoSufijos -> Set String
terminaCon str (CP m)   = buscarPalabra str m 
--Devuelve el conjunto de palabras asociadas a determinado sufijo. O(log(n)).

buscarPalabra :: String -> Map String (Set String) -> Set String
buscarPalabra str m = case (lookupM str m) of
						Nothing  -> emptyS 
						(Just x) -> x
						
agregarSufijos :: String -> ConjuntoSufijos -> ConjuntoSufijos
agregarSufijos str (CP m)  = CP (agregarSufijosM str str m)

agregarSufijosM :: [Char]-> String -> Map String (Set String) -> Map String (Set String)
agregarSufijosM [] str m   = assocM m xs str 
agregarSufijosM (x:xs) str m = assocM (agregarSufijosM xs str m) (x:xs) str

--Asocia una palabra a cada uno de sus sufijos. O(s.log(n)).

borrarSufijos :: String -> ConjuntoSufijos -> ConjuntoSufijos
borrarSufijos str (CP m) = borrarPalabra str str m

borrarPalabra :: [Char] -> String -> Map String (Set String) -> Map String (Set String)
borrarPalabra [] str m     = m
borrarPalabra (x:xs) str m = if (size(buscarSet m str) > 1)
								then (assocM (borrarPalabra xs str) xs (remove str (buscarSet m xs)))
								else (deleteM (borrarPalabra xs str) str)
								
buscarSet :: Map String (Set String) -> String -> (Set String)
buscarSet m str = case (lookupM m str)  of 
								Nothing -> error "No esta el elemento"
								Just x  -> x
								


