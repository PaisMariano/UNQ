import ConjuntoSufijos

conjuntoSufijos :: Tree ConjuntoSufijos -> Set String
conjuntoSufijos EmptyT          = empty
conjuntoSufijos (NodeT x t1 t2) = union (todasLasPalabras x) (union (conjuntoSufijos t1) (conjuntoSufijos t2))
													 
todasLasPalabras :: ConjuntoSufijos -> Set String 
todasLasPalabras c  = terminanCon "" c

--Une todas los palabras de los ConjuntoSufijos del arbol.


--al menos un elemento se encuentran en ConjuntoSufijos.

sufijoMayor :: [String] -> ConjuntoSufijos -> String
sufijoMayor []     c = error "
sufijoMayor [x]    c = x
sufijoMayor (x:xs) c = esMayor x (sufijoMayor xs c) c

esMayor :: String -> String -> ConjuntoSufijos -> String
esMayor str str' c = if size(terminaCon str c) >= size(terminaCon str' c)
				then str
				else str'


--Devuelve la palabra de la lista que es sufijo de mayor cantidad de palabras del ConjuntoSufijos.