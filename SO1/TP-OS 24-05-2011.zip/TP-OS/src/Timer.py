import threading

class Timer(threading)

    def __init__(self, time, kernel):

        self.time=time
        self.kernel=kernel

    def 
        t = threading.Timer(30.0, hello)
        t.start() # after 30 seconds, "hello, world" will be printed
