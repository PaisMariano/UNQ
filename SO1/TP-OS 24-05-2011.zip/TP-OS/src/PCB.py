'''
Created on 21/05/2011

@author: Mariano
'''

class PCB(object):
       


    def __init__(self):
        self.id
        self.pc
        self.estado
        
    def setReady(self):
        self.isActive = newState

    def getActive(self):
     return self.isActive

        
    def setWaiting(self):
        
    def setTerminated(self):
        
    def estaTerminado(self):
        
    def estaEsperando(self):
        
        
