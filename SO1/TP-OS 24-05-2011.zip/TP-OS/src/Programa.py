'''
Created on 21/05/2011

@author: Mariano
'''

class Programa(object):
    

    def __init__(self, ids):
        self.instruccion = []
        self.nombre
        self.id =ids
    
    def agregarInstruccion(self, ins):
        self.instruccion = self.instruccion.add(ins)
        
    
