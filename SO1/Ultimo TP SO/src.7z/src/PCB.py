'''
@author: Mariano Pais y Tatiana Molinari.
'''

class PCB(object):
       


    def __init__(self):
        self.id
        self.pc
        self.estado
        
    def setEstado(self, estado):
        self.estado = estado

    def getEstado(self):
     return self.estado

        
