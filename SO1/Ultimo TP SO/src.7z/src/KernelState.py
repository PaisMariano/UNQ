'''
@author: Mariano Pais y Tatiana Molinari.
'''

class KernelState:
    KERNEL_MODE = False
    RUNNING = False
