package TP2;

import java.util.*;

public class ArregloRandom {
	
	Vector<Integer> arreglo = new Vector<Integer> (20);
	
	public void crearArreglo() {		
		
		int val;
		
		int cont = 0;
		
		while (cont < 20){
		
		val = (int)(Math.random()*100);
		
		System.out.println("N�mero aleatorio agregado: " + val );
		
		arreglo.add(val);
		
		cont = cont + 1;
		
						}
		
	}
	
	public void calcularPares(){
		int ind = 0;
		int sum = 0;
		while (ind < 20){
			
		if (esPar(ind)){
			
			sum = sum + arreglo.elementAt(ind);
		}
			
		ind = ind + 1;
				
		}
		System.out.println("La suma de los valores pares es: " + sum);
	}
	
	public void calcularImpares(){
		int ind = 0;
		int sum = 0;
		while (ind < 20){
			
		if(!esPar(ind)){
			
			sum = sum + arreglo.elementAt(ind);
		}
			
		ind = ind + 1;
				
		}
		System.out.println("La suma de los valores impares es: " + sum);
	}
	
	public Boolean esPar(int val){
		if (arreglo.elementAt(val)%2==0)return true; else return false;
		}
	
	


	
	public static void main(String[] args){
		
		ArregloRandom arreglo1 = new ArregloRandom();	
		arreglo1.crearArreglo();
		
	}	
}

