#  Copyright (c) 2010, Oracle and/or its affiliates. All rights reserved.
#
#  This library is free software; you can redistribute it and/or
#  modify it under the terms of the GNU Lesser General Public
#  License as published by the Free Software Foundation; either
#  version 2 of the License, or (at your option) any later version.
#
#  This library is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public
#  License along with this library; if not, write to the
#  Free Software Foundation, Inc., 59 Temple Place - Suite 330,
#  Boston, MA 02111-1307, USA.

from wb import DefineModule
import grt

from mforms import Utilities, ResultOk, AppView, newWebBrowser, App
import mforms

import sys
import platform
import mysqldoclib
import thread
import socket
import os
import time


ModuleInfo = DefineModule(name= "WbDocLib", author= "Oracle", version="1.0")


docLibTab = None

class DocLibTab(AppView):
    def __init__(self, server_port):
        AppView.__init__(self, False, "doclib", True)

        self.browser = newWebBrowser()
        self.add(self.browser, True, True)
        
        self.browser.add_loaded_callback(self.loaded)
        self.browser.navigate("http://localhost:%i" % server_port)
        
        self.on_close(self.handle_on_close)
      
    def handle_on_close(self):
        global docLibTab
        App.get().set_status_text("Closed Doc Library")
        docLibTab = None
        return True

    
    def loaded(self, url):
        App.get().set_view_title(self, "Doc Library")
        App.get().set_status_text("Doc Library Opened")


def run_server(datadir, server_port):
    mysqldoclib.serve_docs(server_port, datadir=datadir)


server_port = None
    
@ModuleInfo.plugin("wb.doclib.open", type="standalone", caption= "Open Documentation Library",  pluginMenu= "Extensions")
@ModuleInfo.export(grt.INT)
def openDocLib():
    global docLibTab
    global server_port
    if docLibTab:
      if docLibTab is True:
          Utilities.open_url("http://localhost:%i"%server_port)
          return 1
      App.get().select_view("wb.doclib")
      return 1

    app = App.get()

    server_port = 8811
    
    #datadir = "./modules/data/DocLibrary/"
    datadir = os.path.join(app.get_resource_path(""), "modules/data/DocLibrary")
    thread.start_new_thread(run_server, (datadir, server_port))

    time.sleep(1)

    if platform.system() == "Linux":
        docLibTab = True
        Utilities.open_url("http://localhost:%i"%server_port)
        return 1
    docLibTab = DocLibTab(server_port)
    docLibTab.set_identifier("wb.doclib")
    
    app.dock_view(docLibTab, "maintab")
    app.set_view_title(docLibTab, "Doc Library (loading)")

    app.set_status_text("Opening Doc Library...")

    return 1

