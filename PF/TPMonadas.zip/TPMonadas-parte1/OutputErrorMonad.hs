module OutputErrorMonad where

-- COMPLETAR con una definición de tipo 
-- de forma tal que sea al mismo tiempo 
-- instancia de ErrorMonad y de PrintMonad