package main.java.TP1;

public abstract class Task implements Runnable{

}
