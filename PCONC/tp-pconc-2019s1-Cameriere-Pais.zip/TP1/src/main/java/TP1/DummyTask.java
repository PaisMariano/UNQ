package main.java.TP1;

public class DummyTask extends Task{

    @Override
    public void run() {
        System.out.println("Corre Dummy task");
    }
}
