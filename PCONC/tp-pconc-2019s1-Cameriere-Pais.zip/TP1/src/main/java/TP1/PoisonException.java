package main.java.TP1;

public class PoisonException extends RuntimeException {}
